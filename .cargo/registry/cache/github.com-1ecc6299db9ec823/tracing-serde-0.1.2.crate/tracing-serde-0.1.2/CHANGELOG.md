# 0.1.1 (February 27, 2020)

### Added

- Made `SerdeMapVisitor` public (#599)
- Made `SerdeStructVisitor` public (#599)

# 0.1.0 (November 18, 2019)

- Initial release
