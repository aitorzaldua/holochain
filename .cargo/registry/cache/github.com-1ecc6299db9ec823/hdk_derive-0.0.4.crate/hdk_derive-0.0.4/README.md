# hdk_derive

Derive macros for the holochain hdk.
