#[cfg(feature = "parsing")]
pub mod lookahead {
    pub trait Sealed: Copy {}
}
