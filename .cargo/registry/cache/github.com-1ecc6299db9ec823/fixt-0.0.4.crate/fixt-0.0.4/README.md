# Fixturator

Convenient creation for test fixtures.
