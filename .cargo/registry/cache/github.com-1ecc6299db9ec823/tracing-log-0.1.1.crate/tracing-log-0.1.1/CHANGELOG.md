# 0.1.1 (October 29, 2019)

### Deprecated

- `TraceLogger` (use `tracing`'s "log" and "log-always" feature flags instead)

### Fixed

- Issues with `log/std` feature flag (#406)
- Minor documentation issues (#405, #408)

# 0.1.0 (September 3, 2019)

- Initial release
