use paste::paste;

paste! {
    fn [<env! huh>]() {}
}

fn main() {}
