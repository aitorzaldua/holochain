use paste::paste;

paste! {
    fn [<a {} b>]() {}
}

fn main() {}
