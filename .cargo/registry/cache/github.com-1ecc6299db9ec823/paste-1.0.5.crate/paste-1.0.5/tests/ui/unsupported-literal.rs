use paste::paste;

paste! {
    fn [<1e+100>]() {}
}

fn main() {}
