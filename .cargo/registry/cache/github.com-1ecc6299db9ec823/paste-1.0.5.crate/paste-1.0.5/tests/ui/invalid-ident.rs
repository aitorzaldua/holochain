use paste::paste;

paste! {
    fn [<0 f>]() {}
}

fn main() {}
